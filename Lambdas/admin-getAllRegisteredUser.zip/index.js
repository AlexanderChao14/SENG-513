
const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
// var ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
var ddb = new AWS.DynamoDB.DocumentClient();
var statusCode=200;
var body;
exports.handler = async (event, context) => { 
     
    
    let respone=[];
    let allRegisteredUser=await  getALLUsers() 
    console.log("allRegisteredUser: ",allRegisteredUser['Count'])
    console.log("allRegisteredUser: ",allRegisteredUser['Items'])
    if (allRegisteredUser['Count']===0){
        body=respone;
    }
    else{
        
        for (let i=0; i<allRegisteredUser['Count'];i++ ){
            delete allRegisteredUser['Items'][i]["passwordHash"];
            delete allRegisteredUser['Items'][i]["passwordSalt"];
            delete allRegisteredUser['Items'][i]["verified"];
        }
        body=allRegisteredUser['Items']
    }
    
    console.log(allRegisteredUser)
    // TODO implement
    const response = {
        statusCode: statusCode,
        body: body,
    };
    return response;
};




// function getALLUsers() {
   

//     let params = {
//         TableName: "users",
//         ProjectionExpression: "adminVerified, created_at, email,firstName , lastName,role",
//         // FilterExpression: "#yr between :start_yr and :end_yr",
//         // ExpressionAttributeNames: {
//         //     "#yr": "year",
//         // },
//         // ExpressionAttributeValues: {
//         //     ":start_yr": 1950,
//         //     ":end_yr": 1959
//         // }
//     };

//     ddb.scan(params, onScan).promise();;
    
//     function onScan(err, data) {
//         if (err) {
//             return "There is an error in server"
//         } else {
//             return data

                  
//         }
//     }
// }

function getALLUsers(){   
    console.log("####getOnlinePlayers Function called");
    return ddb.scan({   TableName: 'users' }).promise();
}
