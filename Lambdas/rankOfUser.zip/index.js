const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
// var ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
var ddb = new AWS.DynamoDB.DocumentClient();


var statusCode=200;
var body="Works";

exports.handler = async (event, context) => { 


   let result= await allRankUser();
   let ranking=result['Items']
   if (result['Count']>0){
    console.log(result);
       
   body={rankinglist:ranking}
 
   }
   else{
       body={rankinglist:[]}
   }
    




    const response = {
        statusCode: statusCode,
        body:body,
    };
    return response;
};





function allRankUser(){
    var params = {
    TableName: 'rank',
    IndexName:"id-wins-index",
    KeyConditionExpression: 'id = :id',
    ExpressionAttributeValues: { ':id': '1'} ,
    // Limit: 3,
    ScanIndexForward: false,    // true = ascending, false = descending
};
     try{
        return ddb.query(params).promise()
    }
    catch(err){
         console.log(" #### error in query findingUserId",err)
    }
}