

const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
// var ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
var ddb = new AWS.DynamoDB();
var statusCode=200;
var body={message:"Works"};



exports.handler = async (event, context) => {  
   
   
   
    let users= await userTable();
    let rank= await rankTable();
    let game= await gameTable();
    let socketUser= await socketUserTable();
    let waitingList= await waitingListTable();
   
   
   
    const response = {
        statusCode: statusCode,
        body: body,
    };
    return response;
};



function userTable(){

    let params={
    TableName : "users",
    KeySchema: [       
        { AttributeName: "email", KeyType: "HASH"},  //Partition key
        // { AttributeName: "title", KeyType: "RANGE" }  //Sort key
    ],
    AttributeDefinitions: [      
        { AttributeName: "email", AttributeType: "S" }
    ],
    ProvisionedThroughput: {       
        ReadCapacityUnits: 10, 
        WriteCapacityUnits: 10
    }
    }
    
    try{
        return ddb.createTable(params).promise();
    }
    catch(err){
         console.log(" #### error in query",err)
   
    }
}

//////////////////////// socket ////////////////////////////
function socketUserTable(){
     let params={
    TableName : "socketUser",
    KeySchema: [       
        { AttributeName: "connectionId", KeyType: "HASH"}
    ],
    AttributeDefinitions: [      
        { AttributeName: "userId", AttributeType: "S" }
    ],
    ProvisionedThroughput: {       
        ReadCapacityUnits: 10, 
        WriteCapacityUnits: 10
    },
    GlobalSecondaryIndexes:[{
    IndexName:"userId-index",
      KeySchema: [       
        { AttributeName: "userId", KeyType: "HASH"}
    ],
    
        Projection:{
            ProjectionType:"ALL"
        },
                ProvisionedThroughput: {
                    ReadCapacityUnits: 1,
                    WriteCapacityUnits: 1
                }
        
        }]
    };
    
    try{
        return ddb.createTable(params).promise();
    }
    catch(err){
         console.log(" #### error in query",err)
   
    }
}




/////////////////  rank  //////////////////////////
function rankTable(){
    let params={
    TableName : "rank",
    KeySchema: [       
        { AttributeName: "userId", KeyType: "HASH"}
    ],
    AttributeDefinitions: [      
        { AttributeName: "userId", AttributeType: "S" },
         { AttributeName: "wins", AttributeType: "N" }
    ],
    ProvisionedThroughput: {       
        ReadCapacityUnits: 10, 
        WriteCapacityUnits: 10
    },
    GlobalSecondaryIndexes:[{
    IndexName:"id-wins-index",
      KeySchema: [       
        { AttributeName: "userId", KeyType: "HASH"},  //Partition key
        { AttributeName: "wins", KeyType: "RANGE" }  //Sort key
    ],
    
        Projection:{
            ProjectionType:"ALL"
        },
                ProvisionedThroughput: {
                    ReadCapacityUnits: 1,
                    WriteCapacityUnits: 1
                }
        
        }]
    };
    
    try{
        return ddb.createTable(params).promise();
    }
    catch(err){
         console.log(" #### error in query",err)
   
    }
}

function gameTable(){
   let params={
    TableName : "game",
    KeySchema: [       
        { AttributeName: "gameId", KeyType: "HASH"},
         { AttributeName: "userId", KeyType: "RANGE" } 
    ],
    AttributeDefinitions: [      
        { AttributeName: "userId", AttributeType: "S" },
         { AttributeName: "gameId", AttributeType: "S" }
    ],
    ProvisionedThroughput: {       
        ReadCapacityUnits: 10, 
        WriteCapacityUnits: 10
    },
    GlobalSecondaryIndexes:[{
    IndexName:"userId-index",
      KeySchema: [       
        { AttributeName: "userId", KeyType: "HASH"}
    ],
    
        Projection:{
            ProjectionType:"ALL"
        },
                ProvisionedThroughput: {
                    ReadCapacityUnits: 1,
                    WriteCapacityUnits: 1
                }
        
        }]
    };
    
    try{
        return ddb.createTable(params).promise();
    }
    catch(err){
         console.log(" #### error in query",err)
   
    }
}
function waitingListTable(){
    let params={
    TableName : "waitingList",
    KeySchema: [       
        { AttributeName: "userId", KeyType: "HASH"},  //Partition key
    ],
    AttributeDefinitions: [      
        { AttributeName: "userId", AttributeType: "S" }
    ],
    ProvisionedThroughput: {       
        ReadCapacityUnits: 10, 
        WriteCapacityUnits: 10
    }
    }
    
    try{
        return ddb.createTable(params).promise();
    }
    catch(err){
         console.log(" #### error in query",err)
   
    }
}