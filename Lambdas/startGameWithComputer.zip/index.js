//Step 1: I will get id, grid

//Step 2: Check connection, look for user id in socketUser table

//Step 3: Generate game id, add the game id to the game table, first user is the player, second user is the computer (constant id), 

//       store the grid for the user, and have a constant grid for the computer (for now) 

//Step 4: Return a status (talk to the front end guys), game id


const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
// var ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
var ddb = new AWS.DynamoDB.DocumentClient();
var statusCode=200;
var body="Works";
const COMPID = "11111";

exports.handler = async (event, context) => {
    let userId="2";
    let grid = [
    ["A","A","A","A",0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0],
    ["B",0,0,0,0,0,0,0,0,0],
    ["B",0,0,0,0,0,0,0,0,0],
    ["B",0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,"E","E","E",0,0],
    [0,0,0,0,0,0,0,0,0,0],
    [0,0,"D",0,0,0,0,0,0,0],
    [0,0,"D",0,0,0,"C","C","C",0]
    ];
    
    //name of the fleet
    // A : 5    B :3,   C:3  D:2 E : 3
    let aircraftCarrier=  4;// "A"
    let submarine=  3;// "B"
    let destroyer=  3;// "C"
    let cruiser=  2;// "D"
    let battleship=  3;// "E"
    
    //generate game id
    let gameId=idGenerator(); 
    console.log("#### game Id: ",gameId);
    
    let flag = false;
    
    let players = await getOnlinePlayers();
    console.log(players);
    let onlineUserIds = [];
    let userConnectionId = "";
    for(let i = 0; i < players['Count']; i++){
      console.log(i);
      
      if(userId === players['Items'][i]['userId']){
        flag = true;
        userConnectionId = players['Items'][i]['connectionId'];
      }
    }
    //Check if the user is playing another game, if the user is playing another game, reject the game request (dont add the game to the game table)
    
    
    //{ Items: [], Count: 0, ScannedCount: 0 }
    if((players['Count'] === 0) || (!flag) ) {
      statusCode = 400; 
      body = "User does not exist in the database";
    }
    
    
    else if(flag) {
      try{
      console.log("Users exists, flag is true");
      //adding game id to the game table
      console.log("### Point 2: saving this grid in dyanmo db");
                    let addParams = {
                    Item: {
                            'gameId':gameId,
                            'userId':  userId,
                            'grid':  grid,
                            'aircraftCarrier':  aircraftCarrier,
                            'submarine':  submarine,
                            'destroyer':  destroyer,
                            'cruiser':  cruiser,
                            'battleship':  battleship,
                    },
                    TableName: "game"
                    };
                    await ddb.put(addParams).promise();
                    console.log("Success the new user added with his grid correctly");
                    let addParamsComputer = {
                    Item: {
                            'gameId':gameId,
                            'userId': COMPID,
                            'grid':  grid,
                            'aircraftCarrier':  aircraftCarrier,
                            'submarine':  submarine,
                            'destroyer':  destroyer,
                            'cruiser':  cruiser,
                            'battleship':  battleship,
                    },
                    TableName: "game"
                    };
                    await ddb.put(addParamsComputer).promise();
                    console.log("Success computer added with his grid correctly");
                    await callingWebsocketBasedOnOneUser("move",userConnectionId,{"opponent":addParamsComputer['Item'],"user":addParams['Item']});
                    body = "Game is ready to begin";
      }
      catch(err) {
        console.log(err);
        statusCode = 400;
        body = "An error occured";
      }
    }
    
    
    
    
    
    //End
    
    console.log("### Point 3: Done");
      const response = {
        statusCode: statusCode,
        // body: JSON.stringify(body),
        body: body,
    }; 
    return response;
    
};

function idGenerator() {
    var S4 = function() {
       return (((1+Math.random())*0x10000)|0).toString(16).substring(1);
    };
    return (S4()+S4()+"-"+S4()+"-"+S4()+"-"+S4()+"-"+S4()+S4()+S4());
}
function getOnlinePlayers(){   
   
    console.log("####getOnlinePlayers Function called");
    return ddb.scan({   TableName: 'socketUser',  }).promise();
}


function callingWebsocketBasedOnOneUser(action,connectionId,data) {

    let info={ "action": action,"data": data};
    const apigwManagementApi = new AWS.ApiGatewayManagementApi({
    apiVersion: "2018-11-29",
    endpoint: "4kflhc6oo7.execute-api.us-east-1.amazonaws.com/dev"
  });
    try {
        return   apigwManagementApi
    .postToConnection({ ConnectionId: connectionId, Data: JSON.stringify(info) }).promise();
    }
    catch(error) {
        console.log(error);
        // statusCode=400;
        // body="error in webSocket: "+error;
        console.log("There is problem in webSocket for this connectionID:",connectionId)
        return error;
    }
}
