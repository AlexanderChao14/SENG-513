

   

//Step 1: At the start, get game id, user id, coordinate x and coordinate y

//Step 2: Check if game id exists in the game table, if exists, check the user id to make sure the user exists as well, if doesnt exist
//          return a terminate game status to the front end, no one wins

//Step 3: Check to see if the user is online in the socketUser table, if the user is not online, delete the game from the game table

//Step 4: Put a mark in the computer grid with the coordinates sent by the player

//Step 5: Check the status of the computer grid
const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
// var ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
var ddb = new AWS.DynamoDB.DocumentClient();
var statusCode=200;
var body="Works";

exports.handler = async (event) => {
    
    // let gameId=event["gameId"];
    // let userId=event["email"]+"";
    // let x_cordinate=event["x_cordinate"];
    // let y_cordinate=event["y_cordinate"];
    let gameId="2a6da504-fdf7-d976-1aed-0144ce1b2b9e"
    let userId="2"
    let x_cordinate=2
    let y_cordinate=0
    
    //Based on the game id we have to retrieve information from game table
    
    
    //Count for both queries must be 1, if not 1, delete the game id from the game table, inform the front end
    
    //Based on the coordinate, change the grid cell to a hit, if it is a 0, change to 1, if it A, B, C,D,E, change that cell t A1, B1, C1, D1, or E1 and decrease the number of ships respectively
    
    //Check the value of ships, if all of them are 0, user wins, else the game continues, computer to move
    
    //Generate a random coordinate, and make sure the coordinate is valid
    
    //Valid coordinate: coordinate cannot be one from before, and cannot be A1, B1, C1, D1, or E1 or 1
    
    //If not valid, generate again, and check again till a valid one is received
    
    //Check the user ships, if all are 0, computer wins, else the game continues
    
    //call websockets, action is move, pass in the grid
    let gameResponse=await findingGame(gameId);
    let compIndex;
    let userIndex;
    if (gameResponse['Count']===2){
        console.log("gameResponse ",gameResponse)
    //1 we have to opponendId:
    //[{"UserId":2,grid:[][],submarine:3,destroyer:4},{"UserId":11111,grid:[][],submarine:3,destroyer:4}]
        if (gameResponse['Items'][0]['userId']===userId){
             compIndex = 1;
             userIndex=0;
        }
        else{
        compIndex = 0;
        userIndex=1;
        }
   
    //gameResponse["Items"][compIndex]["grid"] = [][]
    let opponentGrid = gameResponse["Items"][compIndex]["grid"];
    let opponentAircraftCarrier= gameResponse['Items'][compIndex]['aircraftCarrier']
    let opponentSubmarine= gameResponse['Items'][compIndex]['submarine']
    let opponentDestroyer= gameResponse['Items'][compIndex]['destroyer']
    let opponentCruiser= gameResponse['Items'][compIndex]['cruiser']
    let opponentBattleship= gameResponse['Items'][compIndex]['battleship']
    let valueOf=opponentGrid[x_cordinate][y_cordinate];
                
                if (valueOf==="A" ||valueOf==="B" ||valueOf==="C" ||valueOf==="D" ||valueOf==="E" ){
                    if(valueOf==="A"){
                    console.log("valueOf===A");
                     opponentGrid[x_cordinate][y_cordinate]="A1";  
                     opponentAircraftCarrier=opponentAircraftCarrier-1;
                    }
                    else if (valueOf==="B"){
                    console.log("valueOf===B");
                    opponentGrid[x_cordinate][y_cordinate]="B1";
                    opponentSubmarine=opponentSubmarine-1;
                    }
                     else if (valueOf==="C"){
                         console.log("valueOf===C");
                    opponentGrid[x_cordinate][y_cordinate]="C1";
                    opponentDestroyer=opponentDestroyer-1;
                    }
                     else if (valueOf==="D"){
                         console.log("valueOf===D");
                    opponentGrid[x_cordinate][y_cordinate]="D1";
                    opponentCruiser=opponentCruiser-1;
                    }
                     else if (valueOf==="E"){
                         console.log("valueOf===E");
                    opponentGrid[x_cordinate][y_cordinate]="E1";
                    opponentBattleship=opponentBattleship-1;
                    }
                } 
                else{
                    console.log("valueOf===0");
                    opponentGrid[x_cordinate][y_cordinate]=1;
                }
                
                if (opponentAircraftCarrier===0 && opponentSubmarine===0 && opponentDestroyer===0 && opponentCruiser===0 && opponentBattleship===0)   {
                   // it means this user wins and we have to terminate the game
                    
                    await callingWebsocketBasedOnOneUser("win",userId,{"user":`UserId${userId} win the game`});
                    await  deleteGame(gameId,userId);
                    await  deleteGame(gameId,"11111");
                                        
                }
                else {
                    //generate two random numbers between 0-9
                    //mark the user grid
                    //check if the number is valid, if not regenerate the numbers
                    let userGrid = gameResponse["Items"][userIndex]["grid"];
                    let userAircraftCarrier= gameResponse['Items'][userIndex]['aircraftCarrier'];
                    let userSubmarine= gameResponse['Items'][userIndex]['submarine'];
                    let userDestroyer= gameResponse['Items'][userIndex]['destroyer'];
                    let userCruiser= gameResponse['Items'][userIndex]['cruiser'];
                    let userBattleship= gameResponse['Items'][userIndex]['battleship'];
                    let flag = false;
                    let valueUser;
                    let x_user;
                    let y_user;
                    while(!flag){
                    x_user = getRandomCoordinates();
                    y_user = getRandomCoordinates();
                    valueUser=userGrid[x_user][y_user];
                    
                    if((valueUser === 1 ) || (valueUser === "A1") || (valueUser === "B1") || (valueUser === "C1") || (valueUser === "D1") || (valueUser === "E1") ){
                        flag = false;
                        } 
                    else {
                        flag = true;

                    }
                    }
                    
                    if (valueUser==="A" ||valueUser==="B" ||valueUser==="C" ||valueUser==="D" ||valueUser==="E" ){
                    if(valueUser==="A"){
                    console.log("valueOf===A");
                     userGrid[x_user][y_user]="A1";  
                     userAircraftCarrier=userAircraftCarrier-1;
                    }
                    else if (valueUser==="B"){
                    console.log("valueOf===B");
                    userGrid[x_user][y_user]="B1";
                    userSubmarine=userSubmarine-1;
                    }
                     else if (valueUser==="C"){
                         console.log("valueOf===C");
                    userGrid[x_user][y_user]="C1";
                    userDestroyer=userDestroyer-1;
                    }
                     else if (valueUser==="D"){
                         console.log("valueOf===D");
                    userGrid[x_user][y_user]="D1";
                    userCruiser=userCruiser-1;
                    }
                     else if (valueUser==="E"){
                         console.log("valueOf===E");
                    userGrid[x_user][y_user]="E1";
                    userBattleship=userBattleship-1;
                    }
                } 
                else{
                    console.log("valueOf===0");
                    userGrid[x_user][y_user]=1;
                }
                
                if (userAircraftCarrier===0 && userSubmarine===0 && userDestroyer===0 && userCruiser===0 && userBattleship===0)   {
                   // it means this user wins and we have to terminate the game
                    
                    await callingWebsocketBasedOnOneUser("lose",userId,{"user":`UserId${userId} lose the game`});
                    await  deleteGame(gameId,userId);
                    await  deleteGame(gameId,"11111");
                                        
                }
                else {
                      
                   await updateGameTable(gameId,userId,userGrid,userAircraftCarrier,userSubmarine,userDestroyer,userCruiser,userBattleship);
                   await updateGameTable(gameId,"11111",opponentGrid,opponentAircraftCarrier,opponentSubmarine,opponentDestroyer,opponentCruiser,opponentBattleship);
                   let userItems = {
                            'gameId':gameId,
                            'userId':  userId,
                            'grid':  userGrid,
                            'aircraftCarrier':  userAircraftCarrier,
                            'submarine':  userSubmarine,
                            'destroyer':  userDestroyer,
                            'cruiser':  userCruiser,
                            'battleship':  userBattleship,
                   }
                   let compItem = {
                            'gameId':gameId,
                            'userId':  "11111",
                            'grid':  opponentGrid,
                            'aircraftCarrier':  opponentAircraftCarrier,
                            'submarine':  opponentSubmarine,
                            'destroyer':  opponentDestroyer,
                            'cruiser':  opponentCruiser,
                            'battleship':  opponentBattleship,
                   }
                   await callingWebsocketBasedOnOneUser("move",userId,{"opponent":compItem,"user":userItems}); 
                }
                }
    }
    else {
        console.log("Have to delete the game id from the game table, and if the user exists in the response, notify the user via");
        if(gameResponse["Count"] === 0) {
        statusCode = 400;
        body = "Game does not exist";
        }
        else if(gameResponse["Count"] === 1) {
            if(gameResponse["Items"][0]["userId"] === userId) {
                await callingWebsocketBasedOnOneUser("TERMINATE",userId,{"messsage":"There is problem with this game, try again"});
                await deleteGame(gameId,userId);
            }
            else{
                await  deleteGame(gameId,"11111");
                statusCode = 400;
                body = "Game does not exist";
            }
        }
        else {
            statusCode = 500;
            body = "Server internal error";
        }
    }
    const response = {
        statusCode: statusCode,
        body: body,
    };
    return response;
};

//Finding game function
function findingGame(gameId){
    let params = {
    TableName: 'game',
    //  IndexName:'userId-index',
        KeyConditionExpression: "#gameId = :gameIdValue",
      ExpressionAttributeNames:{
            "#gameId": "gameId"
        },
        ExpressionAttributeValues: {
            ":gameIdValue":gameId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### findingGame",err)
         statusCode=400;
         body="error in findingGame";
    }

    
}

async function callingWebsocketBasedOnOneUser(action,userId,data){
    
    
     try{
     let responseDb=await findingUserId(userId);
     
     console.log(" ####dbResponse",responseDb);
     if(responseDb['Count']===0){
         console.log(" ####This user Id was disconnected : ",userId);
            statusCode=400;
            body="This user Id was disconnected "+userId;   
     }
     else if(responseDb['Count']>=2){
         console.log(" #### more than one user Id found terminate the game: ",userId) ;
         
         
            statusCode=400;
            body="terminate the game, there is problem in the socketUser Table for this user Id "+userId;
     }
     else{
        let connectionId=responseDb['Items']['0']['connectionId'];
        console.log("### conncetionId: ",connectionId)
        // let data={"grid":[1,2,3,4,5,6,7],"userId":userId};
        
        try {
        let res= await callingWebSocket(action,connectionId,data); 
        console.log("webSocket works")}
        catch(err){
            console.log("webSocket does not work")
            statusCode=400;
            body="webSocket does not work: "+err;
            
        }
        
     }
         console.log("query in db works")
     }
      catch(err){
            console.log("query in db does not work callingWebsocketBasedOnOneUser")
            statusCode=400;
            body="query in db does not work: "+err;
          
      }
}



function deleteGame(gameId,userId ){
    let params = {
    TableName: 'game',
    //  IndexName:'userId-index',
    Key:{
        "gameId": gameId,
        "userId":userId
    },
    
        };
    try{
        return ddb.delete(params).promise();
    }
    catch(err){
         console.log(" #### findingGame",err)
         statusCode=400;
         body="error in findingGame";
    }
}

function findingUserId(userId){
    console.log(" #### userId",userId)
        let params = {
        TableName : "socketUser",
        IndexName:'userId-index',
        KeyConditionExpression: "#userId = :userIdValue",
      ExpressionAttributeNames:{
            "#userId": "userId"
        },
        ExpressionAttributeValues: {
            ":userIdValue":userId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### error in query findingUserId",err)
         statusCode=400;
         body="error in query findingUserId";
    }

    
}

function callingWebSocket(action,connectionId,data) {

    let info={ "action": action,"data": data};
    const apigwManagementApi = new AWS.ApiGatewayManagementApi({
    apiVersion: "2018-11-29",
    endpoint: "4kflhc6oo7.execute-api.us-east-1.amazonaws.com/dev"
  });
    try {
        return   apigwManagementApi
    .postToConnection({ ConnectionId: connectionId, Data: JSON.stringify(info) }).promise();
    }
    catch(error) {
        console.log(error);
        // statusCode=400;
        // body="error in webSocket: "+error;
        console.log("There is problem in webSocket for this connectionID:",connectionId)
        return error;
    }
}

function getRandomCoordinates() {
   return Math.floor(Math.random() * (10));
}

function updateGameTable(gameId,userId,grid,aircraftCarrier,submarine,destroyer,cruiser,battleship){
    
    
    var params = {
    TableName:'game',
    Key:{
        "gameId":gameId,
        "userId": userId
    },
    UpdateExpression: "set grid=:grid, aircraftCarrier=:aircraftCarrier ,submarine=:submarine,destroyer=:destroyer,cruiser=:cruiser,battleship=:battleship ",
    ExpressionAttributeValues:{
        ":grid":grid,
        ":aircraftCarrier":aircraftCarrier,
        ":submarine":submarine,
        ":destroyer":destroyer,
        ":cruiser":cruiser,
        ":battleship":battleship,
     
    },
    ReturnValues:"UPDATED_NEW"
};
  try{
        return ddb.update(params).promise();
    }
    catch(err){
         console.log(" #### error in update game table",err)
         statusCode=400;
         body="error in update game table";
    }
}
