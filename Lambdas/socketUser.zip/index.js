const AWS = require('aws-sdk');
require('./patch.js');
require("aws-sdk/clients/apigatewaymanagementapi");

const ddb = new AWS.DynamoDB.DocumentClient({
    apiVersion: '2012-08-10',
    region: process.env.AWS_REGION
}); 

exports.handler = async (event, context, callback) => {
    console.log("################################event:  ",event); 
    console.log("context:  ",context);
    
    // $connect - logs a connectionId
    if (event.requestContext.routeKey === "$connect") {
        console.log('Testing Connect');

        let putParams = {};
        
        if (event.queryStringParameters.player) {
            putParams = {
            TableName: process.env.TABLE_NAME,
            Item: {
                connectionId: event.requestContext.connectionId,
                userId: event.queryStringParameters.player
            }
            }; 
            
        } 
        else if (event.queryStringParameters.guest) {
            putParams = {
            TableName: process.env.TABLE_NAME,
            Item: {
                connectionId: event.requestContext.connectionId,
                guestId: event.queryStringParameters.guest
            }
            };
            } 
        else if (event.queryStringParameters.admin) {
            putParams = {
            TableName: process.env.TABLE_NAME,
            Item: {
                connectionId: event.requestContext.connectionId,
                adminId: event.queryStringParameters.admin
            }
            };
            }  
            else {
            putParams = {
            TableName: process.env.TABLE_NAME,
            Item: {
                connectionId: event.requestContext.connectionId
            }
            };
        }

        try {
            await ddb.put(putParams).promise();
        } catch (err) {
            return {
                statusCode: 500,
                body: 'Failed to connect: ' + JSON.stringify(err)
            };
        }

        return { 
            statusCode: 200,
            body: 'Connected.'
        }; 
    // $disconnect
    }
    else if (event.requestContext.routeKey === "$disconnect") { 
        let userInfo=await  findUserId(event.requestContext.connectionId);
        if (userInfo['Count']!=0){
            if ('userId' in userInfo['Items'][0]){
                console.log("$$$$$$$$$$$$$$$$$$$$$$$$$$",userInfo['Items'][0]['userId']) 
                let res_findingGameId=await findingGameId(userInfo['Items'][0]['userId']); 
                if (res_findingGameId['Count']!=0){
                    console.log("@@@@@@@@@@@@@@@@@@",res_findingGameId['Items'][0]['gameId'])
                    let responseTogetUserWithGameId=await  findingGame(res_findingGameId['Items'][0]['gameId'])
                    if (responseTogetUserWithGameId['Count']===1){
                         console.log("%%%%%%%%%%%%it means this user is alone",responseTogetUserWithGameId['Items'][0]['userId'])
                         await  deleteGame(responseTogetUserWithGameId['Items'][0]['gameId'],responseTogetUserWithGameId['Items'][0]['userId'] )
                         await deleteUserFromWaitingList(responseTogetUserWithGameId['Items'][0]['userId'])
                    } 
                    else if (responseTogetUserWithGameId['Count']===2){ 
                         console.log("%%%%%%%%%%%%it means this user has opponent and we have to delete game for him and inform him also",responseTogetUserWithGameId['Items'][0]['userId'])
                        await  deleteGame(responseTogetUserWithGameId['Items'][0]['gameId'],responseTogetUserWithGameId['Items'][0]['userId'] );
                        await  deleteGame(responseTogetUserWithGameId['Items'][0]['gameId'],responseTogetUserWithGameId['Items'][1]['userId'] );
                        let isOpponent=responseTogetUserWithGameId['Items'][1]['userId']
                        if(isOpponent===userInfo['Items'][0]['userId']){
                            await callingWebsocketBasedOnOneUser("TERMINATE",responseTogetUserWithGameId['Items'][0]['userId'],{"message":"Your opponent left the game"});
                        }
                        else{
                            await callingWebsocketBasedOnOneUser("TERMINATE",isOpponent,{"message":"Your opponent left the game"});
                        }
                        
                    }
                    
                }
                else{
                    console.log("@@@@@@@@@@@@@@@@@@It means this user does not have any game",userInfo['Items'][0]['userId'])
                }
            }
        }
        const deleteParams = {
            TableName: process.env.TABLE_NAME,
            Key: {
                connectionId: event.requestContext.connectionId
            }
        };

        try {
            await ddb.delete(deleteParams).promise();
        } catch (err) {
            return {
                statusCode: 500,
                body: 'Failed to disconnect: ' + JSON.stringify(err)
            };
        }

        return {
            statusCode: 200,
            body: 'Disconnected.'
        };
    // $default
    } 
    else if (event.requestContext.routeKey === "$default") {
        // console.log('test $default');
        // console.log('Connection ID is : ' + event.requestContext.extendedRequestId)
        // send(event, event.requestContext.extendedRequestId);
        return {
                statusCode: 200,
                body: 'Test Ping $default'
        };
    } else {
        // console.log('test else');
        // send(event, event.requestContext.extendedRequestId);
        return {
                statusCode: 200,
                body: 'Test Ping'
        };
    }
};

const send = (event, connectionId) => {
  const postData = 'heartbeat';
  const apigwManagementApi = new AWS.ApiGatewayManagementApi({
    apiVersion: "2018-11-29",
    endpoint: event.requestContext.domainName + "/" + event.requestContext.stage
  });
  return apigwManagementApi
    .postToConnection({ ConnectionId: connectionId, Data: postData })
    .promise();
};

function findUserId(connectionId){
      let params = {
        TableName : "socketUser",
        KeyConditionExpression: "#connectionId = :connectionIdValue",
      ExpressionAttributeNames:{
            "#connectionId": "connectionId"
        },
        ExpressionAttributeValues: {
            ":connectionIdValue":connectionId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### error in query findingUserId",err)
        
    }
    
}

function findingGame(gameId){
    let params = {
    TableName: 'game',
    //  IndexName:'userId-index',
        KeyConditionExpression: "#gameId = :gameIdValue",
      ExpressionAttributeNames:{
            "#gameId": "gameId"
        },
        ExpressionAttributeValues: {
            ":gameIdValue":gameId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### findingGame",err)
       
    }

    
}

function findingGameId(userId){
    let params = {
    TableName: 'game',
     IndexName:'userId-index',
    KeyConditionExpression: "#userId = :userIdValue",
      ExpressionAttributeNames:{
            "#userId": "userId"
        },
        ExpressionAttributeValues: {
            ":userIdValue":userId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### findingGame",err)
       
    }

    
}

function deleteGame(gameId,userId ){
    let params = {
    TableName: 'game',
    //  IndexName:'userId-index',
    Key:{
        "gameId": gameId,
        "userId":userId
    },
    
        };
    try{
        return ddb.delete(params).promise();
    }
    catch(err){
         console.log(" #### findingGame",err)
        
    }
}



function callingWebSocket(action,connectionId,data) {

    let info={ "action": action,"data": data};
    const apigwManagementApi = new AWS.ApiGatewayManagementApi({
    apiVersion: "2018-11-29",
    endpoint: "4kflhc6oo7.execute-api.us-east-1.amazonaws.com/dev"
  });
    try {
        return   apigwManagementApi
    .postToConnection({ ConnectionId: connectionId, Data: JSON.stringify(info) }).promise();
    }
    catch(error) {
        console.log(error);
        // statusCode=400;
        // body="error in webSocket: "+error;
        console.log("There is problem in webSocket for this connectionID:",connectionId)
        return error;
    }
}

async function callingWebsocketBasedOnOneUser(action,userId,data){
     try{
     let responseDb=await findingUserId(userId);
     
     console.log(" ####dbResponse",responseDb);
     if(responseDb['Count']===0){
         console.log(" ####This user Id was disconnected : ",userId);
  
            return;
     }
     else if(responseDb['Count']>=2){
         console.log(" #### more than one user Id found terminate the game: ",userId) ;
         
         
        
            return;
     }
     else{
        let connectionId=responseDb['Items']['0']['connectionId'];
        console.log("### conncetionId: ",connectionId)
        // let data={"grid":[1,2,3,4,5,6,7],"userId":userId};
        
        try {
        let res= await callingWebSocket(action,connectionId,data); 
        console.log("webSocket works")
            return;
        }
        
        catch(err){
            console.log("webSocket does not work")

            
            
        }
        
     }
         console.log("query in db works")
     }
      catch(err){
            console.log("query in db does not work callingWebsocketBasedOnOneUser")
       
          
      }
}
function findingUserId(userId){
    console.log(" #### userId",userId)
        let params = {
        TableName : "socketUser",
        IndexName:'userId-index',
        KeyConditionExpression: "#userId = :userIdValue",
      ExpressionAttributeNames:{
            "#userId": "userId"
        },
        ExpressionAttributeValues: {
            ":userIdValue":userId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### error in query findingUserId",err)
      
    }

    
}

function deleteUserFromWaitingList(userId){
   
    let params = {
    TableName: 'waitingList',
    Key:{
        "userId":userId
    },
    
        };
    try{
        return ddb.delete(params).promise();
    }
    catch(err){
         console.log(" #### waitingList",err)
        
    }

}