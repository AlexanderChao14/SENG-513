
const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
// var ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
var ddb = new AWS.DynamoDB.DocumentClient();
var statusCode=200;
var body={message:"Works"};

exports.handler = async (event, context) => {  
    console.log("event",event)
    let userId=event['email']+"";  
    let grid=event['grid']; 
    
    
    
    
    let aircraftCarrier=  4;// "A"
    let submarine=  3;// "B"
    let destroyer=  3;// "C"
    let cruiser=  2;// "D"
    let battleship=  3;// "E"   
    
    let gameId=idGenerator();
     let userInfo=await findingUserInfo(userId);
    let addParams = {
    Item: {
            'gameId':gameId,
            'userId':  userId,
            'grid':  grid,
            'aircraftCarrier':  aircraftCarrier,
            'submarine':  submarine,
            'destroyer':  destroyer,
            'cruiser':  cruiser,
            'battleship':  battleship,
             'firstName':  userInfo['Items'][0]['firstName']
    },
    TableName: "game"
    };
    await ddb.put(addParams).promise();
    console.log("Success the new user added with his grid correctly");
      
    body={message:"Wait for your friend",gameId:gameId};    
    
   
    // TODO implement
    const response = {
        statusCode: statusCode,
        body: body,
    };
    return response;
};










function idGenerator() {
    var S4 = function() {
       return (((1+Math.random())*0x10000)|0).toString(16).substring(1);
    };
    return (S4()+S4()+"-"+S4()+"-"+S4()+"-"+S4()+"-"+S4()+S4()+S4());
}


function findingUserInfo(userId){
        console.log(" #### userId",userId)
        let params = {
        TableName : "users",
        KeyConditionExpression: "#email = :emailValue",
      ExpressionAttributeNames:{
            "#email": "email"
        },
        ExpressionAttributeValues: {
            ":emailValue":userId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### error in query",err)
         statusCode=400;
         body="error in query";
    }
}