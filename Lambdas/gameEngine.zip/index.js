const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
// var ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
var ddb = new AWS.DynamoDB.DocumentClient();
 
 
var statusCode=200;
var body="Works";  

exports.handler = async (event, context) => { 
    console.log("SSSSSSSSSSSSSOOOOOOOO:   ",event)
    let gameId=""
    let userId=""
    let x_cordinate;
    let y_cordinate;
    if ('apiFromOrdinaryCall' in event ){
     gameId=event["gameId"]; 
     userId=event["email"]+""; 
     x_cordinate=event["x_cordinate"];
     y_cordinate=event["y_cordinate"]; 
    } 
    else{
     let reqFromSocket=JSON.parse(event.body);
        console.log(reqFromSocket)
     gameId=reqFromSocket.data.gameId; 
     userId=reqFromSocket.data.email;
     x_cordinate=reqFromSocket.data.x_cordinate;
     y_cordinate=reqFromSocket.data.y_cordinate;   
        
        
    }
    // 1: gameId
    // 2: userId 
    // 3: x_cordinate
    // 4: y_cordinate 
    // let gameId="7e7ac4ab-6ec9-658e-4628-562fed892ed5"
    // let userId="1"
    // let x_cordinate=0
    // let y_cordinate=0
    // query in game table based on gameId 
            // 1: first we check if two items returned other wise we have termiante the game and send to online player to termiante the game 
            // 2: based on the userId we can figure out which player is opponend
            // 3: do sth with x and y cordinate, and also updates the remaining ...
            // 4: chagne turn og the players and also send the status to them
    
    
    let opponendId;
    let whichIndex;
    let userIndex;
    let gameResponse=await findingGame(gameId)
    if (gameResponse['Count']===2){
        console.log("gameResponse ",gameResponse)
    //1 we have to opponendId:
        if (gameResponse['Items'][0]['userId']===userId){
             opponendId=gameResponse['Items'][1]['userId']
             whichIndex=1;
             userIndex=0;
        }
        else{
            opponendId=gameResponse['Items'][0]['userId']
            whichIndex=0;
            userIndex=1;
        }
        console.log("opponendId:    ",opponendId)
        
        //2 we have to find both user all online:
        let opponendIsOnline=await findingUserId(opponendId)
        let userIsOnline=await findingUserId(userId)
        if (opponendIsOnline['Count']===1 && userIsOnline['Count']===1){
             console.log("Both Player are online")
                    //it means both users are online and we have to start 
                // let winners=checkingWinners();
                ////////////
                let opponentGrid= gameResponse['Items'][whichIndex]['grid'] ;
                
                let opponentAircraftCarrier= gameResponse['Items'][whichIndex]['aircraftCarrier'];
                let opponentSubmarine= gameResponse['Items'][whichIndex]['submarine'];
                let opponentDestroyer= gameResponse['Items'][whichIndex]['destroyer'];
                let opponentCruiser= gameResponse['Items'][whichIndex]['cruiser'];
                let opponentBattleship= gameResponse['Items'][whichIndex]['battleship'];
                let opponentFisrtName= gameResponse['Items'][whichIndex]['firstName'];
                ////////////
                // let userGrid= gameResponse['Items'][userIndex]['grid'] 
                
                // let userAircraftCarrier= gameResponse['Items'][userIndex]['aircraftCarrier']
                // let userSubmarine= gameResponse['Items'][userIndex]['submarine']
                // let userDestroyer= gameResponse['Items'][userIndex]['destroyer']
                // let userCruiser= gameResponse['Items'][userIndex]['cruiser']
                // let userBattleship= gameResponse['Items'][userIndex]['battleship']
                  ////////////
                let valueOf=opponentGrid[x_cordinate][y_cordinate];
                
                if (valueOf==="A" ||valueOf==="B" ||valueOf==="C" ||valueOf==="D" ||valueOf==="E" ){
                    if(valueOf==="A"){
                    console.log("valueOf===A");
                     opponentGrid[x_cordinate][y_cordinate]="A1";  
                     opponentAircraftCarrier=opponentAircraftCarrier-1;
                    }
                    else if (valueOf==="B"){
                        console.log("valueOf===B");
                    opponentGrid[x_cordinate][y_cordinate]="B1";
                    opponentSubmarine=opponentSubmarine-1;
                    }
                     else if (valueOf==="C"){
                         console.log("valueOf===C");
                    opponentGrid[x_cordinate][y_cordinate]="C1";
                    opponentDestroyer=opponentDestroyer-1;
                    }
                     else if (valueOf==="D"){
                         console.log("valueOf===D");
                    opponentGrid[x_cordinate][y_cordinate]="D1";
                    opponentCruiser=opponentCruiser-1;
                    }
                     else if (valueOf==="E"){
                         console.log("valueOf===E");
                    opponentGrid[x_cordinate][y_cordinate]="E1";
                    opponentBattleship=opponentBattleship-1;
                    }
                } 
                else{
                    console.log("valueOf===0");
                    opponentGrid[x_cordinate][y_cordinate]=1;
                }
                    /// check status
                if (opponentAircraftCarrier===0 && opponentSubmarine===0 && opponentDestroyer===0 && opponentCruiser===0 && opponentBattleship===0)   {
                   // it means this user wins and we have to terminate the game
                    await callingWebsocketBasedOnOneUser("lose",opponendId,{"user":`UserId${userId} win the game`});
                    await callingWebsocketBasedOnOneUser("win",userId,{"user":`UserId${userId} win the game`});
                    await  deleteGame(gameId,userId );
                    await  deleteGame(gameId,opponendId );
                                        // add to rank table
                    let userInRank=await findUserInRankTable(userId);
                    let wins=userInRank['Item']['wins']+1;
                    await addToRankTable(userInRank['Item']['userId'],wins)
                }
                else if (opponentAircraftCarrier===0 && opponentSubmarine===0 && opponentDestroyer===0 && opponentCruiser===0 && opponentBattleship===0) {
                    // it means opponend wins and we have to trminate the game
                    console.log("opponend wins");
                    await callingWebsocketBasedOnOneUser("win",opponendId,{"user":`UserId${opponendId} win the game`});
                    await callingWebsocketBasedOnOneUser("lose",userId,{"user":`UserId${opponendId} win the game`});
                    await  deleteGame(gameId,userId );
                    await  deleteGame(gameId,opponendId );
                    // add to rank table
                    let userInRank=await findUserInRankTable(opponendId);
                    let wins=userInRank['Item']['wins']+1;
                    await addToRankTable(userInRank['Item']['userId'],wins)
                }
                else{
                    console.log("turn the game");
                    // update Opeend grid
                    await addOpponentToGameTable(gameId,opponendId,opponentGrid,opponentAircraftCarrier,opponentSubmarine,opponentDestroyer,opponentCruiser,opponentBattleship);
                    let Item= {
                            'gameId':gameId,
                            'userId':  opponendId,
                            'grid':  opponentGrid,
                            'aircraftCarrier':  opponentAircraftCarrier,
                            'submarine':  opponentSubmarine,
                            'destroyer':  opponentDestroyer,
                            'cruiser':  opponentCruiser, 
                            'battleship':  opponentBattleship,
                             'firstName':  opponentFisrtName
                                        }
                    console.log("Calling websocket for changing turn")
                    //send two both player for next round
                    await callingWebsocketBasedOnOneUser("move",opponendId,{"opponent":gameResponse['Items'][userIndex],"user":Item});
                    await callingWebsocketBasedOnOneUser("lock",userId,{"user":gameResponse['Items'][userIndex],"opponent":Item});
                    
                    
                }
                    
                    
                }
        else if (opponendIsOnline['Count']===0 && userIsOnline['Count']===0){
            console.log("We have to delete this gamdId since both players are disconnected")
            await  deleteGame(gameId,userId );
            await  deleteGame(gameId,opponendId );
        }
        else{
            
            if (opponendIsOnline['Count']===0){
                console.log("We have to call web socket for userId to terminate the game and also delete gameId")
                await callingWebsocketBasedOnOneUser("TERMINATE",userIsOnline['Items'][0]['userId'],{"messsage":"There is problem with this game, try again"});
                await  deleteGame(gameId,userId );
                await  deleteGame(gameId,opponendId );
             }
             else if (userIsOnline['Count']===0){
                 console.log("We have to calling web socket for opponend to terminate the game and also delete gameId")
                    await callingWebsocketBasedOnOneUser("TERMINATE",opponendIsOnline['Items'][0]['userId'],{"messsage":"There is problem with this game, try again"});
                    await  deleteGame(gameId,userId );
                    await  deleteGame(gameId,opponendId );
                    body="We have to calling web socket for opponend to terminate the game and also delete gameId";
             }
        }
      
    //Now we have to find which item has this user Id, then the other user would be opponend and we have do sth..
        
    }
    else if(gameResponse['Count']===0 ){
            console.log("This Game does not Exist ",gameId)
            body="This Game does not Exist";
        // await callingWebsocketBasedOnOneUser("TERMINATE",userId,{"message":"This game is taken by another player"}) 
        
    }
    else if (gameResponse['Count']===1){
        console.log("This Game does not  opponend, gameId: ",gameId)
        console.log("we have to notify userId: ",gameResponse['Count'][0]['userId'])
        console.log("we have to notify this user to terminate the game ")
        console.log("and then delete the game from game table ")
        await  deleteGame(gameResponse['Items'][0]['gameId'],gameResponse['Items'][0]['userId'] );
        await callingWebsocketBasedOnOneUser("TERMINATE",gameResponse['Items'][0]['userId'],{"messsage":"There is problem with this game, try again"});
        body="There is problem with this gameId, gameResponse ";
    }
    else{
        console.log("There is problem with this gameId, gameResponse ",gameResponse);
        body="There is problem with this gameId, gameResponse ";
    }
    


    console.log("###  Done");
    const response = {
        statusCode: statusCode,
        // body: JSON.stringify(body),
        body: body,
    }; 
    return response;
};





function findingGame(gameId){
    let params = {
    TableName: 'game',
    //  IndexName:'userId-index',
        KeyConditionExpression: "#gameId = :gameIdValue",
      ExpressionAttributeNames:{
            "#gameId": "gameId"
        },
        ExpressionAttributeValues: {
            ":gameIdValue":gameId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### findingGame",err)
         statusCode=400;
         body="error in findingGame";
    }

    
}



function findingUserId(userId){
    console.log(" #### userId",userId)
        let params = {
        TableName : "socketUser",
        IndexName:'userId-index',
        KeyConditionExpression: "#userId = :userIdValue",
      ExpressionAttributeNames:{
            "#userId": "userId"
        },
        ExpressionAttributeValues: {
            ":userIdValue":userId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### error in query findingUserId",err)
         statusCode=400;
         body="error in query findingUserId";
    }

    
}



async function callingWebsocketBasedOnOneUser(action,userId,data){
    
    
     try{
     let responseDb=await findingUserId(userId);
     
     console.log(" ####dbResponse",responseDb);
     if(responseDb['Count']===0){
         console.log(" ####This user Id was disconnected : ",userId);
            statusCode=400;
            body="This user Id was disconnected "+userId;   
     }
     else if(responseDb['Count']>=2){
         console.log(" #### more than one user Id found terminate the game: ",userId) ;
         
         
            statusCode=400;
            body="terminate the game, there is problem in the socketUser Table for this user Id "+userId;
     }
     else{
        let connectionId=responseDb['Items']['0']['connectionId'];
        console.log("### conncetionId: ",connectionId)
        // let data={"grid":[1,2,3,4,5,6,7],"userId":userId};
        
        try {
        let res= await callingWebSocket(action,connectionId,data); 
        console.log("webSocket works")}
        catch(err){
            console.log("webSocket does not work")
            statusCode=400;
            body="webSocket does not work: "+err;
            
        }
        
     }
         console.log("query in db works")
     }
      catch(err){
            console.log("query in db does not work callingWebsocketBasedOnOneUser")
            statusCode=400;
            body="query in db does not work: "+err;
          
      }
}



function deleteGame(gameId,userId ){
    let params = {
    TableName: 'game',
    //  IndexName:'userId-index',
    Key:{
        "gameId": gameId,
        "userId":userId
    },
    
        };
    try{
        return ddb.delete(params).promise();
    }
    catch(err){
         console.log(" #### findingGame",err)
         statusCode=400;
         body="error in findingGame";
    }
}




function addOpponentToGameTable(gameId,userId,grid,aircraftCarrier,submarine,destroyer,cruiser,battleship){
    
    
    var params = {
    TableName:'game',
    Key:{
        "gameId":gameId,
        "userId": userId
    },
    UpdateExpression: "set grid=:grid, aircraftCarrier=:aircraftCarrier ,submarine=:submarine,destroyer=:destroyer,cruiser=:cruiser,battleship=:battleship ",
    ExpressionAttributeValues:{
        ":grid":grid,
        ":aircraftCarrier":aircraftCarrier,
        ":submarine":submarine,
        ":destroyer":destroyer,
        ":cruiser":cruiser,
        ":battleship":battleship,
     
    },
    ReturnValues:"UPDATED_NEW"
};
  try{
        return ddb.update(params).promise();
    }
    catch(err){
         console.log(" #### error in update game table",err)
         statusCode=400;
         body="error in update game table";
    }
}


function callingWebSocket(action,connectionId,data) {

    let info={ "action": action,"data": data};
    const apigwManagementApi = new AWS.ApiGatewayManagementApi({
    apiVersion: "2018-11-29",
    endpoint: "4kflhc6oo7.execute-api.us-east-1.amazonaws.com/dev"
  });
    try {
        return   apigwManagementApi
    .postToConnection({ ConnectionId: connectionId, Data: JSON.stringify(info) }).promise();
    }
    catch(error) {
        console.log(error);
        // statusCode=400;
        // body="error in webSocket: "+error;
        console.log("There is problem in webSocket for this connectionID:",connectionId)
        return error;
    }
}


function findUserInRankTable(userId){
    
    var params = {
    TableName: 'rank',
    Key:{
        "userId": userId
    }
};
    try{
        return ddb.get(params).promise();
    }
    catch(err){
         console.log(" #### error addToRankTable",err)
         statusCode=400;
         body="error in addToRankTable";
    }
    
}

function addToRankTable(userId,wins){
       var params = {
    TableName:'rank',
    Key:{
        "userId": userId
    },
    UpdateExpression: "set wins=:wins ",
    ExpressionAttributeValues:{
        ":wins":wins
    },
    ReturnValues:"UPDATED_NEW"
};
  try{
        return ddb.update(params).promise();
    }
    catch(err){
         console.log(" #### error addToRankTable",err)
         statusCode=400;
         body="error in addToRankTable";
    }

}