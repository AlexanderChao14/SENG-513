
const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
// var ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
var ddb = new AWS.DynamoDB.DocumentClient();
var statusCode=200;
var body={message:"Works"};
exports.handler = async (event, context) => {  
    console.log("event",event)
    let userId=event['email']+"";  
    let grid=event['grid']; 
    // let userId="erss.99.es@gmail.com"; 
    // let grid = [ 
    // ["A","A","A","A",0,0,0,0,0,0], 
    // [0,0,0,0,0,0,0,0,0,0],
    // ["B",0,0,0,0,0,0,0,0,0],
    // ["B",0,0,0,0,0,0,0,0,0],
    // ["B",0,0,0,0,0,0,0,0,0],
    // [0,0,0,0,0,0,0,0,0,0],
    // [0,0,0,0,0,"E","E","E",0,0],
    // [0,0,0,0,0,0,0,0,0,0],
    // [0,0,"D",0,0,0,0,0,0,0],
    // [0,0,"D",0,0,0,"C","C","C",0]
    // ];
    
    //name of the fleet
    // A : 5    B :3,   C:3  D:2 E : 3
    let aircraftCarrier=  4;// "A"
    let submarine=  3;// "B"
    let destroyer=  3;// "C"
    let cruiser=  2;// "D"
    let battleship=  3;// "E"
    
    let gameId=idGenerator();
    console.log("#### game Id: ",gameId)
    let flag=false; // if there is at least one online user
        // Call DynamoDB
        try {
            //if user
            console.log("#### 111 ")
            let isUserAlreadyPlay=await findingUserIdInGameTable(userId);
            console.log("#### 222 ")
            let playersInTheGame=[]
            let allUsersWhichplaynow= await findingAllPlayersWhichplayingNow();
            console.log("#### 333 ")
            for(let item of allUsersWhichplaynow['Items']){
            // console.log("####Players which currently playing",item);
            if ('userId' in item){
                playersInTheGame.push(item['userId']);
            }
            }
            
            console.log("#### list of the playing now",playersInTheGame);
            if (isUserAlreadyPlay['Count']===0 ){
            // First we check this userId does not play currently
            let allOnlineUsers=await getOnlinePlayers();
            if (allOnlineUsers['Count']==0){
                console.log('### There is not any online user, we should return a falg to user to terminate the game ');
                 body={message:"NOONLINEUSER"};
            }
            else{
            console.log("### All Online Users: ");   
            for(let item of allOnlineUsers['Items']){
                if ('userId' in item && item['userId'] !== userId &&   !playersInTheGame.includes(item['userId'])){
                    console.log('###sendsTO ', item);
                    flag=true;
                    await callingWebSocket("acceptGame",item['connectionId'],gameId);

                    }
                
                    }
                    
                } 
            
            
            if (flag){
                    console.log("### Point 2: saving this grid in dyanmo db");
                    let userInfo=await findingUserInfo(userId);
                    let addParams = {
                    Item: {
                            'gameId':gameId,
                            'userId':  userId,
                            'grid':  grid,
                            'aircraftCarrier':  aircraftCarrier,
                            'submarine':  submarine,
                            'destroyer':  destroyer,
                            'cruiser':  cruiser,
                            'battleship':  battleship,
                            'firstName':  userInfo['Items'][0]['firstName']
                    },
                    TableName: "game"
                    };
                    await ddb.put(addParams).promise();
                    console.log("Success the new user added with his grid correctly");
                      
                    body={message:"WAITTOACCPET_FOR_20SECOND",gameId:gameId}; 
            }
            else{
                body={message:"NOONLINEUSER"};
            }
            
            
        }
        else{
            // 
            console.log("this user cannot play because already he is playing");
            body={message:"CANNOTPLAY"};
        }
            } 
        catch (err) {
            console.log("Error", err);
            statusCode=400;
            body={message:"Internal Server Error in start Game Function"};
        }
    
      
      
    
 
    //  body={"userId":userId,"grid":grid}
    // console.log(userId);
    
    
    // 1: first saving this userID and grid in the db
    
    // 2: sending to all online usere "who want to play through webSicket"
    

    
    

    
    console.log("### Point 3: Done");
      const response = {
        statusCode: statusCode,
        // body: JSON.stringify(body),
        body: body,
    }; 
    return response;
};



function getOnlinePlayers(){   
   
    console.log("####getOnlinePlayers Function called");
    return ddb.scan({   TableName: 'socketUser',  }).promise();
}

function findingAllPlayersWhichplayingNow(){   
    console.log("####getOnlinePlayers Function called");
    return ddb.scan({   TableName: 'game',  }).promise();
}



function callingWebSocket(action,connectionId,data) {
    let gameId={"gameId":data};
    let info={ "action": action,"data": gameId};
    const apigwManagementApi = new AWS.ApiGatewayManagementApi({
    apiVersion: "2018-11-29",
    endpoint: "4kflhc6oo7.execute-api.us-east-1.amazonaws.com/dev"
  });
    try {
        return   apigwManagementApi
    .postToConnection({ ConnectionId: connectionId, Data: JSON.stringify(info) }).promise();
    }
    catch(error) {
        console.log(error);
        // statusCode=400;
        // body="error in webSocket: "+error;
        console.log("There is problem in webSocket for this connectionID:",connectionId)
        return error;
    }
}



 function findingUserIdInGameTable(userId){
        console.log(" #### userId",userId)
        let params = {
        TableName : "game",
        IndexName:'userId-index',
        KeyConditionExpression: "#userId = :userIdValue",
      ExpressionAttributeNames:{
            "#userId": "userId"
        },
        ExpressionAttributeValues: {
            ":userIdValue":userId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### error in query",err)
         statusCode=400;
         body="error in query";
    }
}

//  function findingUserIdInGameTableIfIsOpponent(opponentId){
//         console.log(" #### opponentId",opponentId);
//         let params = {
//         TableName : "game",
//         IndexName:'opponentId-index',
//         KeyConditionExpression: "#userId = :userIdValue",
//       ExpressionAttributeNames:{
//             "#userId": "opponentId"
//         },
//         ExpressionAttributeValues: {
//             ":userIdValue":opponentId
//         }
//         };
//     try{
//         return ddb.query(params).promise();
//     }
//     catch(err){
//          console.log(" #### error in query",err)
//          statusCode=400;
//          body="error in query";
//     }

    
// }
function idGenerator() {
    var S4 = function() {
       return (((1+Math.random())*0x10000)|0).toString(16).substring(1);
    };
    return (S4()+S4()+"-"+S4()+"-"+S4()+"-"+S4()+"-"+S4()+S4()+S4());
}

function findingUserInfo(userId){
        console.log(" #### userId",userId)
        let params = {
        TableName : "users",
        KeyConditionExpression: "#email = :emailValue",
      ExpressionAttributeNames:{
            "#email": "email"
        },
        ExpressionAttributeValues: {
            ":emailValue":userId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### error in query",err)
         statusCode=400;
         body="error in query";
    }
}