


// first we have to find users in waiting list table, if (count==0) it means we dont have any avable game so we have to geenrate game and add two table
//  waitinglsit table and game table for this user

//if count== 1 :
// we get first element ['items'][0] form waiting list which hast game Id and user id--> imidately we check this user is online or not if it is not online
// we have to delete from 2 where ->> waiting list table and also game table this game and also do the same procdure we did for first one


// if count>1:
    

const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
// var ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
var ddb = new AWS.DynamoDB.DocumentClient();
var statusCode=200;
var body={message:"Works"};

exports.handler = async (event, context) => {  
    let userId=event['email']+"";  
    let grid=event['grid']; 

    // let userId="erss.91"; 
    // let grid = [ 
    // ["A","A","A","A",0,0,0,0,0,0], 
    // [0,0,0,0,0,0,0,0,0,0],
    // ["B",0,0,0,0,0,0,0,0,0],
    // ["B",0,0,0,0,0,0,0,0,0],
    // ["B",0,0,0,0,0,0,0,0,0],
    // [0,0,0,0,0,0,0,0,0,0],
    // [0,0,0,0,0,"E","E","E",0,0],
    // [0,0,0,0,0,0,0,0,0,0],
    // [0,0,"D",0,0,0,0,0,0,0],
    // [0,0,"D",0,0,0,"C","C","C",0]
    // ];
    //name of the fleet
    // A : 5    B :3,   C:3  D:2 E : 3
    let aircraftCarrier=  4;// "A"
    let submarine=  3;// "B"
    let destroyer=  3;// "C"
    let cruiser=  2;// "D"
    let battleship=  3;// "E"
    
    let gameIdForFirstTime=idGenerator();
    
    let waitingListResponse=await findingWaitingList()
    console.log(waitingListResponse['Count'])
    if (waitingListResponse['Count']==0){  // there is no opponent , it should wait until one player accpet the game
        // save this user in waitingLisr
        let addParamsInWaitingList = {
            Item: {
                    'gameId':gameIdForFirstTime,
                    'userId':  userId
            },
            TableName: "waitingList"
            };
            await ddb.put(addParamsInWaitingList).promise();        
        
        
        // save this game in game table
         let userInfo=await findingUserInfo(userId);
         let addParams = {
            Item: {
                    'gameId':gameIdForFirstTime,
                    'userId':  userId,
                    'grid':  grid,
                    'aircraftCarrier':  aircraftCarrier,
                    'submarine':  submarine,
                    'destroyer':  destroyer,
                    'cruiser':  cruiser,
                    'battleship':  battleship,
                    'firstName':  userInfo['Items'][0]['firstName']
            },
            TableName: "game"
            };
            await ddb.put(addParams).promise();
            console.log("Success the new user added with his grid correctly");
            
            statusCode=200 
            body={message:"Wait for another player",gameId:gameIdForFirstTime}; 
        
    }
    else{
        //first we get the first one and we delete this user from waiting list
        let opponentId=waitingListResponse['Items'][0]['userId']
        let gameId= waitingListResponse['Items'][0]['gameId']
        await deleteUserFromWaitingList(opponentId);
    
        let findOpponendInGameTable=await  findingGame(gameId);
        if (findOpponendInGameTable['Count']===0){
            console.log("This game Id doesnot exist ")
        }
        else if (findOpponendInGameTable['Count']===1){
            let opponentInfo=await findingUserInfo(opponentId);
            let opponentItem={
                    'gameId':gameId,
                    'userId':  findOpponendInGameTable['Items'][0]['userId'],
                    'grid':  findOpponendInGameTable['Items'][0]['grid'],
                    'aircraftCarrier':  aircraftCarrier,
                    'submarine':  submarine,
                    'destroyer':  destroyer,
                    'cruiser':  cruiser,
                    'battleship':  battleship,
                    'firstName':  opponentInfo['Items'][0]['firstName']
        }
        // add tthis user to the game table
         let NewuserInfo=await findingUserInfo(userId);
         let addParams = {
            Item: {
                    'gameId':gameId,
                    'userId':  userId,
                    'grid':  grid,
                    'aircraftCarrier':  aircraftCarrier,
                    'submarine':  submarine,
                    'destroyer':  destroyer,
                    'cruiser':  cruiser,
                    'battleship':  battleship,
                    'firstName':  NewuserInfo['Items'][0]['firstName']
            },
            TableName: "game"
            };
            await ddb.put(addParams).promise();
            console.log("Success the new user added with his grid correctly");
            let Item={
                 'gameId':gameId,
                    'userId':  userId,
                    'grid':  grid,
                    'aircraftCarrier':  aircraftCarrier,
                    'submarine':  submarine,
                    'destroyer':  destroyer,
                    'cruiser':  cruiser,
                    'battleship':  battleship,
                    'firstName':  NewuserInfo['Items'][0]['firstName']
            }
            await callingWebsocketBasedOnOneUser("move",opponentId,{"opponent":Item,"user":opponentItem})
            await callingWebsocketBasedOnOneUser("lock",userId,{"user":Item,"opponent":opponentItem})
            statusCode=200
            body={message:"Game Started",gameId:gameId};
        }
        else{
            console.log("There is an error to retirve game ID from game Table"); 
        }
    
    } 
    
    

    const response = {
        statusCode: statusCode,
        body: body,
    };
    return response;
};









function findingWaitingList(){   
    console.log("####waitingList Function called");
    return ddb.scan({   TableName: 'waitingList',  }).promise();
}


function idGenerator() {
    var S4 = function() {
       return (((1+Math.random())*0x10000)|0).toString(16).substring(1);
    };
    return (S4()+S4()+"-"+S4()+"-"+S4()+"-"+S4()+"-"+S4()+S4()+S4());
}


function findingUserInfo(userId){
        console.log(" #### userId",userId)
        let params = {
        TableName : "users",
        KeyConditionExpression: "#email = :emailValue",
      ExpressionAttributeNames:{
            "#email": "email"
        },
        ExpressionAttributeValues: {
            ":emailValue":userId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### error in query",err)
         statusCode=400;
         body="error in query";
    }
}



function deleteUserFromWaitingList(userId){
   
    let params = {
    TableName: 'waitingList',
    Key:{
        "userId":userId
    },
    
        };
    try{
        return ddb.delete(params).promise();
    }
    catch(err){
         console.log(" #### waitingList",err)
         statusCode=400;
         body="error in findingGame";
    }

}


function findingGame(gameId){
    let params = {
    TableName: 'game',
    //  IndexName:'userId-index',
        KeyConditionExpression: "#gameId = :gameIdValue",
      ExpressionAttributeNames:{
            "#gameId": "gameId"
        },
        ExpressionAttributeValues: {
            ":gameIdValue":gameId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### findingGame",err)
         statusCode=400;
         body="error in findingGame";
    }

    
}


function callingWebSocket(action,connectionId,data) {

    let info={ "action": action,"data": data};
    const apigwManagementApi = new AWS.ApiGatewayManagementApi({
    apiVersion: "2018-11-29",
    endpoint: "4kflhc6oo7.execute-api.us-east-1.amazonaws.com/dev"
  });
    try {
        return   apigwManagementApi
    .postToConnection({ ConnectionId: connectionId, Data: JSON.stringify(info) }).promise();
    }
    catch(error) {
        console.log(error);
        // statusCode=400;
        // body="error in webSocket: "+error;
        console.log("There is problem in webSocket for this connectionID:",connectionId)
        return error;
    }
}


async function callingWebsocketBasedOnOneUser(action,userId,data){
    
    
     try{
     let responseDb=await findingUserId(userId);
     
     console.log(" ####dbResponse",responseDb);
     if(responseDb['Count']===0){
         console.log(" ####This user Id was disconnected : ",userId);
            statusCode=400;
            body="This user Id was disconnected "+userId;   
     }
     else if(responseDb['Count']>=2){
         console.log(" #### more than one user Id found terminate the game: ",userId) ;
         
         
            statusCode=400;
            body="terminate the game, there is problem in the socketUser Table for this user Id "+userId;
     }
     else{
        let connectionId=responseDb['Items']['0']['connectionId'];
        console.log("### conncetionId: ",connectionId)
        // let data={"grid":[1,2,3,4,5,6,7],"userId":userId};
        
        try {
        let res= await callingWebSocket(action,connectionId,data); 
        console.log("webSocket works")}
        catch(err){
            console.log("webSocket does not work")
            statusCode=400;
            body="webSocket does not work: "+err;
            
        }
        
     }
         console.log("query in db works")
     }
      catch(err){
            console.log("query in db does not work callingWebsocketBasedOnOneUser")
            statusCode=400;
            body="query in db does not work: "+err;
          
      }
}
 function findingUserId(userId){
    console.log(" #### userId",userId)
        let params = {
        TableName : "socketUser",
        IndexName:'userId-index',
        KeyConditionExpression: "#userId = :userIdValue",
      ExpressionAttributeNames:{
            "#userId": "userId"
        },
        ExpressionAttributeValues: {
            ":userIdValue":userId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### error in query findingUserId",err)
         statusCode=400;
         body="error in query findingUserId";
    }

    
}