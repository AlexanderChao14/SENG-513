const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
// var ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
var ddb = new AWS.DynamoDB.DocumentClient();


var statusCode=200;
var body="Game deleted Successfully";






exports.handler = async (event, context) => { 
    console.log("### event: ",event)
    let gameId=event['gameId'];
    let userId=event['email']+"";
    // let gameId="109f7538-1e86-9708-5088-c39b74b9e3b4"
    // let userId="1"
    
    let gameResponse=await findingGame(gameId)
    console.log("### gameResponse: ",gameResponse)
    
    if (gameResponse['Count']===0){
        console.log("### This game Id does not exist")
        body="This game does not exist"
    }
    else if (gameResponse['Count']===1){
        console.log("###This game Id  exist and we have to check this game Id belongs to this user or opponend")
        if (gameResponse['Items'][0]['userId']===userId){
            console.log("###It means this game has not any opponent so we just need to delete this game")
            await  deleteGame(gameId,userId );
            await  deleteUserFromWaitingList(userId);
            statusCode=200;
            body="Game deleted Successfully"
        } 
        else{
            console.log("###It means we have to delete this game for opponent we have to check logic of the game ");
            statusCode=400;
            body="There is an error, because you want to delete this game for another user";
        }
        
    }
    
    else if (gameResponse['Count']===2){
        console.log("###this means one players wants to terminate the game so we should notify the opponent which this game is terminated through webSocket")
        let opponendId=gameResponse['Items'][0]['userId']
        let userIdFromResposnse=gameResponse['Items'][1]['userId']
        await  deleteGame(gameId,opponendId );
        await  deleteGame(gameId,userIdFromResposnse );
        if (userIdFromResposnse===userId){
            await callingWebsocketBasedOnOneUser("TERMINATE",opponendId,{"message":"Your opponend terminate the game"});
            await callingWebsocketBasedOnOneUser("TERMINATE",userIdFromResposnse,{"message":"You delete the game Sucessfuly"});
        }
        else{
            await callingWebsocketBasedOnOneUser("TERMINATE",opponendId,{"message":"You delete the game Sucessfuly"});
            await callingWebsocketBasedOnOneUser("TERMINATE",userIdFromResposnse,{"message":"Your opponend terminate the game"});
        }
        
    }
    // TODO implement
    const response = {
        statusCode: statusCode,
        body: body,
    };
    return response;
};








function deleteGame(gameId,userId ){
    let params = {
    TableName: 'game',
    //  IndexName:'userId-index',
    Key:{
        "gameId": gameId,
        "userId":userId
    },
    
        };
    try{
        return ddb.delete(params).promise();
    }
    catch(err){
         console.log(" #### findingGame",err)
         statusCode=400;
         body="error in findingGame";
    }
}
 
function findingGame(gameId){
    let params = {
    TableName: 'game',
    //  IndexName:'userId-index',
        KeyConditionExpression: "#gameId = :gameIdValue",
      ExpressionAttributeNames:{
            "#gameId": "gameId"
        },
        ExpressionAttributeValues: {
            ":gameIdValue":gameId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### findingGame",err)
         statusCode=400;
         body="error in findingGame";
    }

    
}




function findingUserId(userId){
    console.log(" #### userId",userId)
        let params = {
        TableName : "socketUser",
        IndexName:'userId-index',
        KeyConditionExpression: "#userId = :userIdValue",
      ExpressionAttributeNames:{
            "#userId": "userId"
        },
        ExpressionAttributeValues: {
            ":userIdValue":userId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### error in query findingUserId",err)
         statusCode=400;
         body="error in query findingUserId";
    }

    
}


function callingWebSocket(action,connectionId,data) {

    let info={ "action": action,"data": data};
    const apigwManagementApi = new AWS.ApiGatewayManagementApi({
    apiVersion: "2018-11-29",
    endpoint: "4kflhc6oo7.execute-api.us-east-1.amazonaws.com/dev"
  });
    try {
        return   apigwManagementApi
    .postToConnection({ ConnectionId: connectionId, Data: JSON.stringify(info) }).promise();
    }
    catch(error) {
        console.log(error);
        // statusCode=400;
        // body="error in webSocket: "+error;
        console.log("There is problem in webSocket for this connectionID:",connectionId)
        return error;
    }
}



async function callingWebsocketBasedOnOneUser(action,userId,data){
    
    
     try{
     let responseDb=await findingUserId(userId);
     
     console.log(" ####dbResponse",responseDb);
     if(responseDb['Count']===0){
         console.log(" ####This user Id was disconnected : ",userId);
            statusCode=400;
            body="This user Id was disconnected "+userId;   
            return;
     }
     else if(responseDb['Count']>=2){
         console.log(" #### more than one user Id found terminate the game: ",userId) ;
         
         
            statusCode=400;
            body="terminate the game, there is problem in the socketUser Table for this user Id "+userId;
            return;
     }
     else{
        let connectionId=responseDb['Items']['0']['connectionId'];
        console.log("### conncetionId: ",connectionId)
        // let data={"grid":[1,2,3,4,5,6,7],"userId":userId};
        
        try {
        let res= await callingWebSocket(action,connectionId,data); 
        console.log("webSocket works")
            return;
        }
        
        catch(err){
            console.log("webSocket does not work")
            statusCode=400;
            body="webSocket does not work: "+err;
            
            
        }
        
     }
         console.log("query in db works")
     }
      catch(err){
            console.log("query in db does not work callingWebsocketBasedOnOneUser")
            statusCode=400;
            body="query in db does not work: "+err;
          
      }
}


function deleteUserFromWaitingList(userId){
   
    let params = {
    TableName: 'waitingList',
    Key:{
        "userId":userId
    },
    
        };
    try{
        return ddb.delete(params).promise();
    }
    catch(err){
         console.log(" #### waitingList",err)
         statusCode=400;
         body="error in findingGame";
    }

}