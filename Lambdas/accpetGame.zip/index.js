const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
// var ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
var ddb = new AWS.DynamoDB.DocumentClient();


var statusCode=200;
var body="Works"; 
exports.handler = async (event, context) => { 
    let userId=event['email']+"";
    let gameId=event['gameId']
    let grid=event['grid']; 
    // let userId="hejazi.iman@gmail.com"; 
    // let gameId="4a98bead-145e-bdad-1a75-bc7f3aef50a2";
    // let grid = [
    // [0,0,0,0,0,0,"A","A","A","A"],
    // [0,0,0,0,0,0,0,0,0,0],
    // ["B",0,0,0,0,0,0,0,0,0],
    // ["B",0,0,0,0,0,0,0,0,0],
    // ["B",0,0,0,0,0,0,0,0,0],
    // [0,0,0,0,0,0,0,0,0,0],
    // [0,0,0,0,0,"E","E","E",0,0],
    // [0,0,0,0,0,0,0,0,0,0],
    // [0,0,"D",0,0,0,0,0,0,0],
    // [0,0,"D",0,0,0,"C","C","C",0]
    // ];
        //name of the fleet
    // A : 5    B :3,   C:3  D:2 E : 3
    let aircraftCarrier=  4;// "A"
    let submarine=  3;// "B"
    let destroyer=  3;// "C" 
    let cruiser=  2;// "D"
    let battleship=  3;// "E"
    let userInfo=await findingUserInfo(userId);
    let firstName=userInfo['Items'][0]['firstName']
    console.log("First Name:     ",firstName)
    let Item= { 
                            'gameId':gameId,
                            'userId':  userId,
                            'grid':  grid,
                            'aircraftCarrier':  aircraftCarrier,
                            'submarine':  submarine,
                            'destroyer':  destroyer,
                            'cruiser':  cruiser,
                            'battleship':  battleship,
                            'firstName':  firstName,
    }
    
    // 1: first check both connection are open 
 
    
    
    // 2 : frist we have to check gameId is available   
    // how? :  query in dynamo db in game table--> if gameId exist and  does not  two players
    let gameResponse=await findingGame(gameId)
    if (gameResponse['Count']===0 || gameResponse['Count']===2){
        console.log("This Game does not Exist, gameId: ",gameId)
        await callingWebsocketBasedOnOneUser("TERMINATE",userId,{"message":"This game is taken by another player"})
    }
    else {
        let opponentId= gameResponse['Items'][0]['userId']
         let allOnlineUser=await getOnlinePlayers();
         console.log("All online users: ",allOnlineUser)
         if (allOnlineUser['Count']===0){
                console.log('### There is not any online user, we should return a falg to user to terminate the game ');
                await deleteGame(gameId,opponentId)
                console.log("### Game Deleted ")
                 body="NOONLINEUSER";
             }
            ///////
        let opponentIsActive=false;
        let userIsActive=false;
        let strangePlayers=[];
        for(let item of allOnlineUser['Items']){
             if ('userId' in item && item['userId'] ===userId ){
                 userIsActive=true;
             }
             else if ('userId' in item &&  item['userId'] ===opponentId){
                 opponentIsActive=true;
             }
             if('userId' in item && item['userId'] !==opponentId && item['userId'] !==userId ){
                 console.log("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$") 
                 
                 strangePlayers.push(item['userId'])
             }  
             
         }
         console.log("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$: ",strangePlayers)
        if (opponentIsActive && userIsActive){
                    let responseAfterAddThisUser=await addOpponentToGameTable(gameId,userId,grid,aircraftCarrier,submarine,destroyer,cruiser,battleship,firstName);
        console.log("### responseAfterAddThisUser: ",responseAfterAddThisUser)
        await callingWebsocketBasedOnOneUser("move",opponentId,{"opponent":Item,"user":gameResponse['Items'][0]})
        await callingWebsocketBasedOnOneUser("lock",userId,{"user":Item,"opponent":gameResponse['Items'][0]})
        for(let h=0;h<strangePlayers.length; h++){
            console.log("### @@@@@@@@@@@@@@@@@@@@@@@ ",strangePlayers[h])  
        //   await callingWebSocket("removeAcceptGame",strangePlayers[h],{"message":"This game is taken by another player"});
          await callingWebsocketBasedOnOneUser("removeAcceptGame",strangePlayers[h],{"message":"This game is taken by another player"});
        } 
        body="GAMESTARTED"
        }
        else if (opponentIsActive){
            console.log("### opponent left the game so we should tell this user there is no game and delete the game in game table ")
            await deleteGame(gameId,opponentId)
            console.log("### Game Deleted ")
        }
        else if (userIsActive){
            console.log("### This is user is not active so we wait until another user take this game ")
            body="Your conncetion with server is disconnected please try later"
        }
        else{
            console.log("### None of them are online so we have to terminate the game ")
            await deleteGame(gameId,opponentId)
            await deleteGame(gameId,userId)
            console.log("### Game Deleted ")
        }
        

    } 
    
    
    

    
    
    
    console.log("###  Done");
     const response = {
        statusCode: statusCode,
        // body: JSON.stringify(body),
        body: body,
    }; 
    return response;
};







       

function findingGame(gameId){
    let params = {
    TableName: 'game',
    //  IndexName:'userId-index',
        KeyConditionExpression: "#gameId = :gameIdValue",
      ExpressionAttributeNames:{
            "#gameId": "gameId"
        },
        ExpressionAttributeValues: {
            ":gameIdValue":gameId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### findingGame",err)
         statusCode=400;
         body="error in findingGame";
    }

    
}



// function addOpponentToGameTable(userId,opponentId,opponentGrid){
    
    
//     var params = {
//     TableName:'game',
//     Key:{
//         "userId": userId
//     },
//     UpdateExpression: "set opponentGrid=:opponentGrid, opponentId=:opponentId",
//     ExpressionAttributeValues:{
//         ":opponentId":opponentId,
//         ":opponentGrid":opponentGrid,
     
//     },
//     ReturnValues:"UPDATED_NEW"
// };
//   try{
//         return ddb.update(params).promise();
//     }
//     catch(err){
//          console.log(" #### error in update game table",err)
//          statusCode=400;
//          body="error in update game table";
//     }
// }



function callingWebSocket(action,connectionId,data) {

    let info={ "action": action,"data": data};
    const apigwManagementApi = new AWS.ApiGatewayManagementApi({
    apiVersion: "2018-11-29",
    endpoint: "4kflhc6oo7.execute-api.us-east-1.amazonaws.com/dev"
  });
    try {
        return   apigwManagementApi
    .postToConnection({ ConnectionId: connectionId, Data: JSON.stringify(info) }).promise();
    }
    catch(error) {
        console.log(error);
        // statusCode=400;
        // body="error in webSocket: "+error;
        console.log("There is problem in webSocket for this connectionID:",connectionId)
        return error;
    }
}


async function callingWebsocketBasedOnOneUser(action,userId,data){
    
    
     try{
     let responseDb=await findingUserId(userId);
     
     console.log(" ####dbResponse",responseDb);
     if(responseDb['Count']===0){
         console.log(" ####This user Id was disconnected : ",userId);
            statusCode=400;
            body="This user Id was disconnected "+userId;   
     }
     else if(responseDb['Count']>=2){
         console.log(" #### more than one user Id found terminate the game: ",userId) ;
         
         
            statusCode=400;
            body="terminate the game, there is problem in the socketUser Table for this user Id "+userId;
     }
     else{
        let connectionId=responseDb['Items']['0']['connectionId'];
        console.log("### conncetionId: ",connectionId)
        // let data={"grid":[1,2,3,4,5,6,7],"userId":userId};
        
        try {
        let res= await callingWebSocket(action,connectionId,data); 
        console.log("webSocket works")}
        catch(err){
            console.log("webSocket does not work")
            statusCode=400;
            body="webSocket does not work: "+err;
            
        }
        
     }
         console.log("query in db works")
     }
      catch(err){
            console.log("query in db does not work callingWebsocketBasedOnOneUser")
            statusCode=400;
            body="query in db does not work: "+err;
          
      }
}

 function findingUserId(userId){
    console.log(" #### userId",userId)
        let params = {
        TableName : "socketUser",
        IndexName:'userId-index',
        KeyConditionExpression: "#userId = :userIdValue",
      ExpressionAttributeNames:{
            "#userId": "userId"
        },
        ExpressionAttributeValues: {
            ":userIdValue":userId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### error in query findingUserId",err)
         statusCode=400;
         body="error in query findingUserId";
    }

    
}

function addOpponentToGameTable(gameId,userId,grid,aircraftCarrier,submarine,destroyer,cruiser,battleship,firstName){
    
    let addParams = {
                    Item: {
                            'gameId':gameId,
                            'userId':  userId,
                            'grid':  grid,
                            'aircraftCarrier':  aircraftCarrier,
                            'submarine':  submarine,
                            'destroyer':  destroyer,
                            'cruiser':  cruiser,
                            'battleship':  battleship,
                            'firstName':firstName
                    },
                    TableName: "game"
                    };
    try{
     return ddb.put(addParams).promise();
    }
    catch(err){
        console.log("Error in addOpponentToGameTable")
        body="Error in addOpponentToGameTable";
    }
    
    
}


function getOnlinePlayers(){   
   
    console.log("####getOnlinePlayers Function called");
    return ddb.scan({   TableName: 'socketUser',  }).promise();
}


function deleteGame(gameId,userId ){
    let params = {
    TableName: 'game',
    //  IndexName:'userId-index',
    Key:{
        "gameId": gameId,
        "userId":userId
    },
    
        };
    try{
        return ddb.delete(params).promise();
    }
    catch(err){
         console.log(" #### findingGame",err)
         statusCode=400;
         body="error in findingGame";
    }
}
 

function findingUserInfo(userId){
        console.log(" #### userId",userId)
        let params = {
        TableName : "users",
        KeyConditionExpression: "#email = :emailValue",
      ExpressionAttributeNames:{
            "#email": "email"
        },
        ExpressionAttributeValues: {
            ":emailValue":userId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### error in query",err)
         statusCode=400;
         body="error in query";
    }
}