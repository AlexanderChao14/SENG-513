
const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
// var ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
var ddb = new AWS.DynamoDB.DocumentClient();
var statusCode=200;
var body={message:"Works"};



exports.handler = async (event, context) => {
    
    
    
     let reqFromSocket=JSON.parse(event.body);
    
     let gameId=reqFromSocket.data.gameId; 
     let userId=reqFromSocket.data.email;
     let text=reqFromSocket.data.text;
    let currentTime=reqFromSocket.data.currentTime
    
    let userInfo=await findingUserInfo(userId);
    let firstName=userInfo['Items'][0]['firstName']
    let gameResponse=await findingGame(gameId)
    
    if (gameResponse['Count']===2){
        
        if (gameResponse['Items'][0]['userId']===userId){
            await callingWebsocketBasedOnOneUser("chat",gameResponse['Items'][1]['userId'],{"text":text,"currentTime":currentTime,"firstName":firstName});
        }
        else{
            await callingWebsocketBasedOnOneUser("chat",gameResponse['Items'][0]['userId'],{"text":text,"currentTime":currentTime,"firstName":firstName});
        }
        
    }
    else{
        console.log("This gameId does not have opponend")
    }
    
    
    
    
    
    
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda!'),
    };
    return response;
};




function findingGame(gameId){
    let params = {
    TableName: 'game',
    //  IndexName:'userId-index',
        KeyConditionExpression: "#gameId = :gameIdValue",
      ExpressionAttributeNames:{
            "#gameId": "gameId"
        },
        ExpressionAttributeValues: {
            ":gameIdValue":gameId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### findingGame",err)
         statusCode=400;
         body="error in findingGame";
    }

    
}
async function callingWebsocketBasedOnOneUser(action,userId,data){
    
    
     try{
     let responseDb=await findingUserId(userId);
     
     console.log(" ####dbResponse",responseDb);
     if(responseDb['Count']===0){
         console.log(" ####This user Id was disconnected : ",userId);
            statusCode=400;
            body="This user Id was disconnected "+userId;   
     }
     else if(responseDb['Count']>=2){
         console.log(" #### more than one user Id found terminate the game: ",userId) ;
         
         
            statusCode=400;
            body="terminate the game, there is problem in the socketUser Table for this user Id "+userId;
     }
     else{
        let connectionId=responseDb['Items']['0']['connectionId'];
        console.log("### conncetionId: ",connectionId)
        // let data={"grid":[1,2,3,4,5,6,7],"userId":userId};
        
        try {
        let res= await callingWebSocket(action,connectionId,data); 
        console.log("webSocket works")}
        catch(err){
            console.log("webSocket does not work")
            statusCode=400;
            body="webSocket does not work: "+err;
            
        }
        
     }
         console.log("query in db works")
     }
      catch(err){
            console.log("query in db does not work callingWebsocketBasedOnOneUser")
            statusCode=400;
            body="query in db does not work: "+err;
          
      }
}

function findingUserId(userId){
    console.log(" #### userId",userId)
        let params = {
        TableName : "socketUser",
        IndexName:'userId-index',
        KeyConditionExpression: "#userId = :userIdValue",
      ExpressionAttributeNames:{
            "#userId": "userId"
        },
        ExpressionAttributeValues: {
            ":userIdValue":userId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### error in query findingUserId",err)
         statusCode=400;
         body="error in query findingUserId";
    }

    
}

function callingWebSocket(action,connectionId,data) {

    let info={ "action": action,"data": data};
    const apigwManagementApi = new AWS.ApiGatewayManagementApi({
    apiVersion: "2018-11-29",
    endpoint: "4kflhc6oo7.execute-api.us-east-1.amazonaws.com/dev"
  });
    try {
        return   apigwManagementApi
    .postToConnection({ ConnectionId: connectionId, Data: JSON.stringify(info) }).promise();
    }
    catch(error) {
        console.log(error);
        // statusCode=400;
        // body="error in webSocket: "+error;
        console.log("There is problem in webSocket for this connectionID:",connectionId)
        return error;
    }
}
function findingUserInfo(userId){
        console.log(" #### userId",userId)
        let params = {
        TableName : "users",
        KeyConditionExpression: "#email = :emailValue",
      ExpressionAttributeNames:{
            "#email": "email"
        },
        ExpressionAttributeValues: {
            ":emailValue":userId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### error in query",err)
         statusCode=400;
         body="error in query";
    }
}