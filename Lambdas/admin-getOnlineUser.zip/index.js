const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
// var ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
var ddb = new AWS.DynamoDB.DocumentClient();
var statusCode=200;
var body=[];
exports.handler = async (event, context) => { 
    
    
    
    
        let allOnlineUsers=await getOnlinePlayers();
        let listOfOnlineUserEmails=[];
        for(let item of allOnlineUsers['Items']){
            // console.log("####Players which currently playing",item);
            if ('userId' in item){
                listOfOnlineUserEmails.push(item['userId']);
            }
            else if ('admin' in item){
            listOfOnlineUserEmails.push(item['admin']);}
            }    
            
        console.log(listOfOnlineUserEmails)
            
            
        let objToReturn=[];
        for(let email of listOfOnlineUserEmails){
            // console.log("####Players which currently playing",item);
            let userInfo=await findingUser(email)
            let res= await buildingResponse(userInfo)
            objToReturn.push(res);
            
            }  
    
    
        body=objToReturn;
    
    
    
    
    // TODO implement
    const response = {
        statusCode: statusCode,
        body: body,
    };
    return response;
};





function getOnlinePlayers(){   
   
    console.log("####getOnlinePlayers Function called");
    return ddb.scan({   TableName: 'socketUser',  }).promise();
}



function findingUser(email){
        console.log(" #### userId",email)
        let params = {
        TableName : "users",
        KeyConditionExpression: "#email  = :emailValue",
      ExpressionAttributeNames:{
            "#email": "email"
        },
        ExpressionAttributeValues: {
            ":emailValue":email
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### error in query",err)
         statusCode=400;
         body="error in findingUserIdInSocketUserTable";
    }
}



function buildingResponse(allRegisteredUser){
    

        delete allRegisteredUser['Items'][0]["passwordHash"];
         delete allRegisteredUser['Items'][0]["passwordSalt"];
        delete allRegisteredUser['Items'][0]["verified"];
        
     
    
    return  allRegisteredUser['Items'][0];
}