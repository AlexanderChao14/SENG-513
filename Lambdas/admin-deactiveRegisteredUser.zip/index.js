const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
// var ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
var ddb = new AWS.DynamoDB.DocumentClient();
var statusCode=200;
var body;
exports.handler = async (event, context) => {  
    let email=event['email']+"";
    // let email="seyediman.hejazi@ucalgary.ca"
    
    let isThisUserPlayingGame=await findingUserIdInGameTable(email);
    let isOnline=await findingUserIdInSocketUserTable(email);
    let userInfo=await findingUser(email);
    
    
    
    
    if (isThisUserPlayingGame['Count']===0){
        
        if (isOnline['Count']===0){
            if (userInfo['Count']===1){
                
                if (userInfo['Items'][0]['adminVerified']==true){
                    let a=await updateUserTable(email,false)
                    console.log("#########   false #################")
                    let allRegisteredUser=await  getALLUsers();
                    body= await buildingResponse(allRegisteredUser)
                }
                else{
                      let b= await updateUserTable(email,true)
                      console.log("###########  true ###############")
                      let allRegisteredUser=await  getALLUsers();
                        body= await buildingResponse(allRegisteredUser)
                }
                
            }
            else{
            statusCode=400;
            body="User not Found";    
            }
            
            
        }
        else{
        statusCode=400;
        body="Plaser try later, this user is online";    
        }
        
        
        
    }
    else{
         statusCode=400;
        body="Plaser try later, this user is playing";
    }
    
    // TODO implement
    const response = {
        statusCode: statusCode,
        body: body,
    };
    return response;
};






function getALLUsers(){   
    console.log("####getOnlinePlayers Function called");
    return ddb.scan({   TableName: 'users' }).promise();
}
 function findingUserIdInGameTable(userId){
        console.log(" #### userId",userId)
        let params = {
        TableName : "game",
        IndexName:'userId-index',
        KeyConditionExpression: "#userId = :userIdValue",
      ExpressionAttributeNames:{
            "#userId": "userId"
        },
        ExpressionAttributeValues: {
            ":userIdValue":userId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### error in query",err)
         statusCode=400;
         body="error in findingUserIdInGameTable";
    }
}



 function findingUserIdInSocketUserTable(userId){
        console.log(" #### userId",userId)
        let params = {
        TableName : "socketUser",
        IndexName:'userId-index',
        KeyConditionExpression: "#userId = :userIdValue",
      ExpressionAttributeNames:{
            "#userId": "userId"
        },
        ExpressionAttributeValues: {
            ":userIdValue":userId
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### error in query",err)
         statusCode=400;
         body="error in findingUserIdInSocketUserTable";
    }
}

 function findingUser(email){
        console.log(" #### userId",email)
        let params = {
        TableName : "users",
        KeyConditionExpression: "#email  = :emailValue",
      ExpressionAttributeNames:{
            "#email": "email"
        },
        ExpressionAttributeValues: {
            ":emailValue":email
        }
        };
    try{
        return ddb.query(params).promise();
    }
    catch(err){
         console.log(" #### error in query",err)
         statusCode=400;
         body="error in findingUserIdInSocketUserTable";
    }
}



function updateUserTable(email,adminVerified){
    
    
    var params = {
    TableName:'users',
    Key:{
        "email":email
    },
    UpdateExpression: "set adminVerified=:adminVerified",
    ExpressionAttributeValues:{
        ":adminVerified":adminVerified
    },
    ReturnValues:"UPDATED_NEW"
};
  try{
        return ddb.update(params).promise();
    }
    catch(err){
         console.log(" #### error in updateUserTable",err)
         statusCode=400;
         body="error in updateUserTable";
    }
}




function buildingResponse(allRegisteredUser){
    let respone;
    if (allRegisteredUser['Count']===0){
        respone=[];
    }
    else{
        
        for (let i=0; i<allRegisteredUser['Count'];i++ ){
            delete allRegisteredUser['Items'][i]["passwordHash"];
            delete allRegisteredUser['Items'][i]["passwordSalt"];
            delete allRegisteredUser['Items'][i]["verified"];
        }
        respone=allRegisteredUser['Items']
    }
    return respone;
}